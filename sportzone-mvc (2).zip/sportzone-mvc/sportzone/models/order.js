const db = require('../config/db');

// Bảng orders đã nằm trong db/schema.sql.

exports.create = o => db.query(
  'INSERT INTO orders (code,user_uid,name,phone,address,note,items,total) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
  [o.code, o.userUid || null, o.name, o.phone, o.address, o.note, JSON.stringify(o.items), o.total]
);

// Trang cảm ơn chỉ cần mã, món và tổng tiền (không lộ tên, SĐT, địa chỉ).
exports.byCode = async code => {
  const r = (await db.query('SELECT code, total, items FROM orders WHERE code = $1', [code])).rows[0];
  return r && { ...r, items: JSON.parse(r.items) };
};
