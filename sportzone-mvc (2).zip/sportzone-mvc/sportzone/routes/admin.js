const router = require('express').Router();
const c = require('../controllers/adminController');

const w = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', w(c.list));
router.get('/products/new', w(c.newForm));
router.post('/products', w(c.create));
router.get('/products/:id/edit', w(c.editForm));
router.post('/products/:id', w(c.update));
router.post('/products/:id/delete', w(c.remove));

module.exports = router;